package com.d3if2070.galerihewan

data class Hewan(
        val nama: String,
        val namaLatin: String,
        val jenis: String,
        val imageResId: Int
)